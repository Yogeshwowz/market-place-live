<section class="about_section">
        <div class="about_banner" style="background-image: url('<?php echo base_url();?>assets/front-end/img/about-banner2.jpg');">
            <div class="about_banner_bg d-flex flex-column justify-content-center align-items-center">
                <h1 class="text-white pt-2">ABOUT US</h1>
            </div>
        </div>
    </section>
	<section class="about_section_body py_80 bg_white">
        <div class="container">
            <h2 class="pb-4">What is Lorem Ipsum !</h2>
            <div class="row">
                <div class="col-md-6">
                    <h5 class="pb-3">Lorem Ipsum making investment banking accessible to small and medium enterprises.</h5>
                    <p class="pb-3">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                </div>
                <div class="col-md-6">
                    <div class="row">
                        <div class="col-md-6">
                            <h6 class="pb-3 pl-1">Who uses LOREM IPSUM</h6>
                            <ul class="about_us_list">
                                <li><i class="fa fa-check-square-o pr-2 pt-1" aria-hidden="true"></i><p>Businesses For Sale</p></li>
                                <li><i class="fa fa-check-square-o pr-2 pt-1" aria-hidden="true"></i><p>Companies Seeking Capital</p></li>
                                <li><i class="fa fa-check-square-o pr-2 pt-1" aria-hidden="true"></i><p>Franchise Brands</p></li>
                                <li><i class="fa fa-check-square-o pr-2 pt-1" aria-hidden="true"></i><p>Boutique Investment Banks</p></li>
                                <li><i class="fa fa-check-square-o pr-2 pt-1" aria-hidden="true"></i><p>M&amp;A Advisors</p></li>
                                <li><i class="fa fa-check-square-o pr-2 pt-1" aria-hidden="true"></i><p>Business Brokers</p></li>
                                <li><i class="fa fa-check-square-o pr-2 pt-1" aria-hidden="true"></i><p>Privare Investors</p></li>
                                <li><i class="fa fa-check-square-o pr-2 pt-1" aria-hidden="true"></i><p>Corporate Acquirers</p></li>
                                <li><i class="fa fa-check-square-o pr-2 pt-1" aria-hidden="true"></i><p>Lenders</p></li>
                                <li><i class="fa fa-check-square-o pr-2 pt-1" aria-hidden="true"></i><p>PE/VC/Funds</p></li>
                                <li><i class="fa fa-check-square-o pr-2 pt-1" aria-hidden="true"></i><p>DealProfessionals</p></li>
                            </ul>
                        </div>
                        <div class="col-md-6">
                            <h6 class="pb-3 pl-1">Why LOREM IPSUM</h6>
                            <ul class="about_us_list">
                                <li><i class="fa fa-check-square-o pr-2 pt-1" aria-hidden="true"></i><p>Simple and straight forward</p></li>
                                <li><i class="fa fa-check-square-o pr-2 pt-1" aria-hidden="true"></i><p>Pre-approved profiles only</p></li>
                                <li><i class="fa fa-check-square-o pr-2 pt-1" aria-hidden="true"></i><p> Confidential "no name" profiles till introduction is made</p></li>
                                <li><i class="fa fa-check-square-o pr-2 pt-1" aria-hidden="true"></i><p>Automatic matching of profiles</p></li>
                                <li><i class="fa fa-check-square-o pr-2 pt-1" aria-hidden="true"></i><p>Insights to improve your profile</p></li>
                                <li><i class="fa fa-check-square-o pr-2 pt-1" aria-hidden="true"></i><p>Instant 'rule of thumb' valuation</p></li>
                                <li><i class="fa fa-check-square-o pr-2 pt-1" aria-hidden="true"></i><p>Ratings to sort good profiles</p></li>
                                <li><i class="fa fa-check-square-o pr-2 pt-1" aria-hidden="true"></i><p>Easy Messaging and Doc Sharing</p></li>                                
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
