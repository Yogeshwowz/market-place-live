<div class="main-content" style="margin-top: 89px;">
<div class="container">
<div class="row">
<div class="main-narrow-content">
<div class="col-md-12">
<div>
<h2 class="mb-3"><center>Client Testimonials</center></h2>
</div>
<div class="row grid" >
	<div class="grid-item grid-sizer col-xs-12 col-sm-6 col-md-4" >
		<div class="first-testi">
			<p class="userImg">
			<img class="testi-img" src="assets/img/testi-1.png" alt="image of testimonial"><span class="userName">User</span>
			</p><p class="profiles"><img class="img-testUser" src="assets/img/user.png">
			Founder,consultant of Banglore
			</p>
			<p></p>
			<div class="green-tag">
			<span class="circle"></span>
			<p>Successfully closed a deal with the 2nd buyer introduced. Time taken to connect: 1 day.</p>
			</div>
			<div class="testi-content">
			<p>The team at S which worked with us to build the Franchise brochure and ROI model 
			for Y5home was reliable and pleasant to interact with. In fact, working with them helped us 
			better understand and also refine our distributorship model to ensure that our distributors
			would be profitable at the earliest. </p>
			
			</div>
		</div>
	</div>
	<div class="grid-item grid-sizer col-xs-12 col-sm-6 col-md-4" >
		<div class="first-testi">
			<p class="userImg">
			<img class="testi-img" src="assets/img/testi-1.png" alt="image of testimonial"><span class="userName">User</span>
			</p><p class="profiles"><img class="img-testUser" src="assets/img/user.png">
			Founder,consultant of Banglore
			</p>
			<p></p>
			<div class="green-tag">
			<span class="circle"></span>
			<p>Successfully closed a deal with the 2nd buyer introduced. Time taken to connect: 1 day.</p>
			</div>
			<div class="testi-content">
			<p>The team at S which worked with us to build the Franchise brochure and ROI model 
			for Y5home was reliable and pleasant to interact with. In fact, working with them helped us 
			better understand and also refine our distributorship model to ensure that our distributors
			would be profitable at the earliest. </p>
			
			</div>
		</div>
	</div>
	<div class="grid-item grid-sizer col-xs-12 col-sm-6 col-md-4" >
		<div class="first-testi">
			<p class="userImg">
			<img class="testi-img" src="assets/img/testi-1.png" alt="image of testimonial"><span class="userName">User</span>
			</p><p class="profiles"><img class="img-testUser" src="assets/img/user.png">
			Founder,consultant of Banglore
			</p>
			<p></p>
			<div class="green-tag">
			<span class="circle"></span>
			<p>Successfully closed a deal with the 2nd buyer introduced. Time taken to connect: 1 day.</p>
			</div>
			<div class="testi-content">
			<p>The team at S which worked with us to build the Franchise brochure and ROI model 
			for Y5home was reliable and pleasant to interact with. In fact, working with them helped us 
			better understand and also refine our distributorship model to ensure that our distributors
			would be profitable at the earliest. </p>
			
			</div>
		</div>
	</div>
</div>

<div >
<h2 class="m-5"><center>Few of our other Successful Deals</center></h2>
</div>
<div class="row grid mb-2" >
	<div class="grid-item grid-sizer col-xs-12 col-sm-6 col-md-4" >
		<div class="first-testi">
			<p class="userImg">
			<img class="testi-img" src="assets/img/testi-1.png" alt="image of testimonial"><span class="userName">User</span>
			</p><p class="profiles"><img class="img-testUser" src="assets/img/user.png">
			Founder,consultant of Banglore
			</p>
			<p></p>
			<div class="green-tag">
			<span class="circle"></span>
			<p>Successfully closed a deal with the 2nd buyer introduced. Time taken to connect: 1 day.</p>
			</div>
			<div class="testi-content">
			<p>The team at S which worked with us to build the Franchise brochure and ROI model 
			for Y5home was reliable and pleasant to interact with. In fact, working with them helped us 
			better understand and also refine our distributorship model to ensure that our distributors
			would be profitable at the earliest. </p>
			
			</div>
		</div>	
	</div>
	<div class="grid-item grid-sizer col-xs-12 col-sm-6 col-md-4" >
		<div class="first-testi">
			<p class="userImg">
			<img class="testi-img" src="assets/img/testi-1.png" alt="image of testimonial"><span class="userName">User</span>
			</p><p class="profiles"><img class="img-testUser" src="assets/img/user.png">
			Founder,consultant of Banglore
			</p>
			<p></p>
			<div class="green-tag">
			<span class="circle"></span>
			<p>Successfully closed a deal with the 2nd buyer introduced. Time taken to connect: 1 day.</p>
			</div>
			<div class="testi-content">
			<p>The team at S which worked with us to build the Franchise brochure and ROI model 
			for Y5home was reliable and pleasant to interact with. In fact, working with them helped us 
			better understand and also refine our distributorship model to ensure that our distributors
			would be profitable at the earliest. </p>
			
			</div>
		</div>	
	</div>
	<div class="grid-item grid-sizer col-xs-12 col-sm-6 col-md-4" >
		<div class="first-testi">
			<p class="userImg">
			<img class="testi-img" src="assets/img/testi-1.png" alt="image of testimonial"><span class="userName">User</span>
			</p><p class="profiles"><img class="img-testUser" src="assets/img/user.png">
			Founder,consultant of Banglore
			</p>
			<p></p>
			<div class="green-tag">
			<span class="circle"></span>
			<p>Successfully closed a deal with the 2nd buyer introduced. Time taken to connect: 1 day.</p>
			</div>
			<div class="testi-content">
			<p>The team at S which worked with us to build the Franchise brochure and ROI model 
			for Y5home was reliable and pleasant to interact with. In fact, working with them helped us 
			better understand and also refine our distributorship model to ensure that our distributors
			would be profitable at the earliest. </p>
			
			</div>
		</div>	
	</div>
</div>
</div>
<div class="clear"></div>
</div>
</div>
</div>
</div>

